Java version: 11
Project name: Warehouse manager
Authors: Daniel Marek(xmarek72) Kateřina Neprašová (xnepra01)

The Warehouse manager is an app that simulates activity in the warehouse. The controls of the warehouse are accessible through the GUI, 
that allows both reading files and inserting manually to initialize and use the the warehouse.

