rm -r javafx-sdk-16
wget  -c  https://download2.gluonhq.com/openjfx/16/openjfx-16_linux-x64_bin-sdk.zip
unzip openjfx-16_linux-x64_bin-sdk.zip
rm openjfx-16_linux-x64_bin-sdk.zip